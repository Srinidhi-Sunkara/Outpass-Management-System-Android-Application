package com.example.realme;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    Button signup;
    EditText password,regno;
    Button login;
    CheckBox remember;
    SharedPreferences preferences;
    SharedPreferenceConfig preferenceConfig;
//    private Button mSendData;
//    private FirebaseDatabase firebaseDatabase =FirebaseDatabase.getInstance();
//    private DatabaseReference mRootReference=firebaseDatabase.getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        signup=(Button)findViewById(R.id.signup);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,signup.class);
                startActivity(intent);
            }
        });


        password=(EditText)findViewById(R.id.loginpassword);
        regno=(EditText)findViewById(R.id.loginregno);
        remember=(CheckBox)findViewById(R.id.remember_me);
        login=(Button)findViewById(R.id.login);
        preferenceConfig=new SharedPreferenceConfig(getApplicationContext());
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginUser(view);
            }
        });

        //second one
//        preferences=getSharedPreferences("checkbox",MODE_PRIVATE);
//        String checkbox=preferences.getString("remember","");
//        if(checkbox.equals("true")){
//            Intent intent=new Intent(MainActivity.this,home.class);
//            startActivity(intent);
//
//        }
//        else if(checkbox.equals("false")){
//            Toast.makeText(MainActivity.this,"please sign in",Toast.LENGTH_SHORT).show();
//
//        }
//        login.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent=new Intent(MainActivity.this,home.class);
//                startActivity(intent);
//            }
//        });
//        remember.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                if(compoundButton.isChecked()){
//                    preferences=getSharedPreferences("checked",MODE_PRIVATE);
//                    SharedPreferences.Editor editor=preferences.edit();
//                    editor.putString("remember","true");
//                    editor.apply();
//                    Toast.makeText(MainActivity.this,"checked",Toast.LENGTH_SHORT).show();
//
//                }else if(!compoundButton.isChecked()){
//                    preferences=getSharedPreferences("checked",MODE_PRIVATE);
//                    SharedPreferences.Editor editor=preferences.edit();
//                    editor.putString("remember","false");
//                    editor.apply();
//                    Toast.makeText(MainActivity.this,"unchecked",Toast.LENGTH_SHORT).show();
//
//                }
//            }
//        });

//first

//        mSendData=(Button)findViewById(R.id.sendData);
//        mSendData.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                FirebaseDatabase database = FirebaseDatabase.getInstance();
//
//                for(int i=1;i<=5;i++){
//                    String path="traildatabase/"+String.valueOf(i)+"/rollno";
//                    DatabaseReference myRef = database.getReference(path);
//                    String rollno="312217205"+String.valueOf(100+i);
//                    myRef.setValue(rollno);
//
//                }
//                Intent intent=new Intent(MainActivity.this,signup.class);
//                startActivity(intent);
//
//            }
//        });

            if(preferenceConfig.readLoginStatus()){
                startActivity(new Intent(MainActivity.this,home.class));
            }
  }
  public void loginUser(View view){

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference().child("Login").child(regno.getText().toString());
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String value=dataSnapshot.child("password").getValue(String.class);
                Toast.makeText(MainActivity.this,value,Toast.LENGTH_SHORT).show();
                String rno=regno.getText().toString();
                String pass=password.getText().toString();
                if(value.equals(pass)){
                startActivity(new Intent(MainActivity.this,home.class));
                preferenceConfig.writeLoginStatus(true);
                finish();}
                else{
                    Toast.makeText(MainActivity.this,"wrong password",Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

  }
}
//    FirebaseDatabase database = FirebaseDatabase.getInstance();
//    DatabaseReference myRef = database.getReference().child("Login").child(regno.getText().toString());
//                myRef.addValueEventListener(new ValueEventListener() {
//@Override
//public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//        String pass=dataSnapshot.child("password").getValue(String.class).toString();
//        if(password.getText().toString().equals(pass)){
//        Toast.makeText(MainActivity.this,pass,Toast.LENGTH_SHORT).show();
//       }
//        else{
//        Toast.makeText(MainActivity.this,"wrong password",Toast.LENGTH_SHORT).show();
//        }
//        }
//
//@Override
//public void onCancelled(@NonNull DatabaseError databaseError) {
//
//        }
//        });
