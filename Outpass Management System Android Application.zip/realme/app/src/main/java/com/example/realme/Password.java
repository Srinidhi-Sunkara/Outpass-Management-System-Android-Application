package com.example.realme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Password extends AppCompatActivity {
    EditText Password,RePassword;
    FirebaseDatabase mDatabase;
    DatabaseReference mReferenceLogin;
    Button setPassword;
    String regno;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);
        Intent intent = getIntent();
        regno = intent.getStringExtra("regno");
        Password=(EditText)findViewById(R.id.Password);
        RePassword=(EditText)findViewById(R.id.re_password);
        mDatabase= FirebaseDatabase.getInstance();
        setPassword=(Button)findViewById(R.id.setPassword);
        setPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();


                    String path="Login/"+String.valueOf(regno)+"/password";
                Toast.makeText(Password.this,path,Toast.LENGTH_SHORT).show();
                    DatabaseReference myRef = database.getReference(path);

                    myRef.setValue(Password.getText().toString());
                    Intent intent=new Intent(Password.this,MainActivity.class);
                    startActivity(intent);

//               mReferenceLogin = mDatabase.getReference("Login/"+regno+"/password");
//               mReferenceLogin.setValue(Password);


            }
        });
    }
}
