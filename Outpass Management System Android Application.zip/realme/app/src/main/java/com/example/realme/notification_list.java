package com.example.realme;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class notification_list extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_list);
    }
}
