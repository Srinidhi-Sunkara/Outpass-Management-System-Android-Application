package com.example.realme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class signup extends AppCompatActivity {
    String path,rollno;
    Button signup;
    EditText regno,name,phno,email;
    TextView result;
    FirebaseDatabase mDatabase;
    DatabaseReference mReferenceStudent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        mDatabase= FirebaseDatabase.getInstance();
        result=(TextView)findViewById(R.id.result);
        name=(EditText)findViewById(R.id.name);
        phno=(EditText)findViewById(R.id.MobileNo);
        email=(EditText)findViewById(R.id.loginregno);

        signup=(Button)findViewById(R.id.signupbtn);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                regno=(EditText)findViewById(R.id.regno);
                Toast.makeText(signup.this,"student/"+regno.getText().toString(),Toast.LENGTH_SHORT).show();
                //mReferenceStudent=mDatabase.getReference("student/"+regno.getText().toString());
                mReferenceStudent=mDatabase.getReference().child("student").child(regno.getText().toString());
                mReferenceStudent.addValueEventListener(new ValueEventListener() {

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        // This method is called once with the initial value and again
                        // whenever data at this location is updated.
                        if(dataSnapshot.exists()){

                            String mobile = phno.getText().toString().trim();
                            String regnumber=regno.getText().toString();
                            Toast.makeText(signup.this,mobile,Toast.LENGTH_SHORT).show();

                            if(mobile.isEmpty() || mobile.length() < 10){
                                phno.setError("Enter a valid mobile");
                                phno.requestFocus();
                                return;
                            }
//
                            Intent verify_intent = new Intent(signup.this, VerifyPhoneActivity.class);
                            verify_intent.putExtra("mobile", mobile);
                            verify_intent.putExtra("regno",regnumber);
                            startActivity(verify_intent);
                            //String student_name = dataSnapshot.child("name").getValue().toString();
                            //String student_email = dataSnapshot.child("email").getValue().toString();
                            // String student_phno = dataSnapshot.child("phno").getValue().toString();
                            //name.setText(student_name);
                            //email.setText(student_email);
                            //  mReferenceStudent.child("phno").setValue(phno.getText().toString());
                        //Toast.makeText(signup.this,value,Toast.LENGTH_SHORT).show();
                        //Log.d("ankur", "Value is: " + student_name);
                        }
                        else{
                            name.setText("error");
                            result.setText("does not exist");
                        }

                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        Toast.makeText(signup.this,"error", Toast.LENGTH_LONG).show();
                        // Failed to read value
                        //name.setText(String.valueOf(error));
                        //Log.w("ankur", "Failed to read value.", error.toException());
                    }
                });
            }
        });
    }


}
